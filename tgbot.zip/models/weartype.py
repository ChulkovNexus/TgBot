from enum import Enum


class WearType(Enum):
    Pants = "Pants"
    Chest = "Chest"
    Shirt = "Shirt"
    Helmet = "Helmet"
    Body = "Body"
    Default = "Default"

