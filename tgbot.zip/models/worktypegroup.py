from enum import Enum


class WorkTypeGroup(Enum):
    Default = "Default"
    Outside = "Outside"
    Inside = "Inside"
